#ifndef UTILS_H
#define UTILS_H

int getIntInput();
float getFloatInput();
void getStringInput(char *str, int size);

#endif